﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Claim;
using SBM_BLC1.Entity.Common;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text;
using SBM_BLC1.Entity.Transaction;
using SBM_BLC1.Transaction;

namespace SBM_WebUI.mp
{
    public partial class TransactionsUpload : System.Web.UI.Page
    {
        #region Local Variable
        CryptographyManager oCrypManager = new CryptographyManager();
        public const string OBJ_TRANSC_ID = "sTranscID";
        public const string OBJ_PAGE_ID = "sPageID";
        public const string SES_ROW_INDEX = "sRowIndex";
        public const string SEC_RE_DATA = "sesReOrderData";
        #endregion Local Variable

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((System.Web.UI.Control)this.Page, oConfig, (int)Constants.PAGEINDEX_TRANS.SP_ISSUE))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }
        private void InitializeData()
        {
            gvData.PageSize = (int)Constants.PAGING_UNAPPROVED;
            // Issue set in session 
            txtTransactionDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);
            txtUploadDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);

            txtFileDetails.Text = "";

            DataTable dt1 = new DataTable();
            gvTransactionList.DataSource = dt1;
            gvTransactionList.DataBind();

            gvData.DataSource = dt1;
            gvData.DataBind();


            // Issue set in session 
            if (Session[Constants.SES_TRANSACTION_UPLOAD] == null)
            {
                NCSTransaction oSesTransactionUpload = new NCSTransaction();
                Session.Add(Constants.SES_TRANSACTION_UPLOAD, oSesTransactionUpload);
            }
            else
            {
                NCSTransaction oSesTransactionUpload = new NCSTransaction();
                Session[Constants.SES_TRANSACTION_UPLOAD] = oSesTransactionUpload;
            }


            string sTranID = Request.QueryString[OBJ_TRANSC_ID];
            string sPageID = Request.QueryString[OBJ_PAGE_ID];

            if (!string.IsNullOrEmpty(sTranID))
            {
                sTranID = oCrypManager.GetDecryptedString(sTranID, Constants.CRYPT_PASSWORD_STRING);
            }
            if (!string.IsNullOrEmpty(sPageID))
            {
                sPageID = oCrypManager.GetDecryptedString(sPageID, Constants.CRYPT_PASSWORD_STRING);
            }

            if (!string.IsNullOrEmpty(sTranID) && !string.IsNullOrEmpty(sPageID))
            {
                string sOperationType = sPageID.Substring(4, 1);
                if (Constants.OPERATION_TYPE_APPROVAL.Equals(sOperationType))
                {
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    LoadDataByID(sTranID, false);

                    // user Detail
                    Util.ControlEnabled(ucUserDet.FindControl("txtCheckerComments"), true);

                    //EnableDisableControl(true);
                    btnApprove.Enabled = true;
                    btnReset.Enabled = true;
                    btnSave.Enabled = false;
                    btnReset.Enabled = false;
                    btnDelete.Enabled = false;
                    btnUploadFile.Enabled = false;

                    #region User-Detail.
                    UserDetails oUserDetails = ucUserDet.UserDetail;
                    oUserDetails.CheckerID = oConfig.UserName;
                    oUserDetails.CheckDate = DateTime.Now;
                    ucUserDet.UserDetail = oUserDetails;
                    #endregion User-Detail.
                }
            }
            else
            {

                //EnableDisableControl(false);
                btnApprove.Enabled = false;
                btnReset.Enabled = false;
                btnSave.Enabled = true;
                btnReset.Enabled = true;
                btnDelete.Enabled = true;
                btnUploadFile.Enabled = true;

                Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                UserDetails oUserDetails = new UserDetails();
                oUserDetails.MakerID = oConfig.UserName;
                oUserDetails.MakeDate = DateTime.Now;
                ucUserDet.UserDetail = oUserDetails;

                LoadUnapproveList();
            }
        }
        private void LoadUnapproveList()
        {
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
            NSCUploadDAL oNSCUploadDAL = new NSCUploadDAL();
            Result oResult = oNSCUploadDAL.LoadUnapprovedList(oConfig.UserName);
            DataTable dtTmpList = (DataTable)oResult.Return;
            if (dtTmpList.Rows.Count > 0)
            {
                dtTmpList.Columns.Remove("Maker ID");

                gvData.DataSource = dtTmpList;
                gvData.DataBind();
            }
            else
            {
                gvData.DataSource = null;
                gvData.DataBind();
            }

            Session[Constants.SES_CONFIG_UNAPPROVE_DATA] = dtTmpList;
        }
        protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvData.PageIndex = e.NewPageIndex;
            if (Session[Constants.SES_CONFIG_UNAPPROVE_DATA] != null)
            {
                DataTable dtTmpList = (DataTable)Session[Constants.SES_CONFIG_UNAPPROVE_DATA];
                gvData.DataSource = dtTmpList;
                gvData.DataBind();
            }
        }
        private void LoadDataByID(string sTranID, bool sApprovalStaus)
        {
            NCSTransaction oNCSTransaction = new NCSTransaction(sTranID);
            NSCUploadDAL oNCSUploadDAL = new NSCUploadDAL();
            Result oResult = new Result();
            oResult = oNCSUploadDAL.LoadByID(oNCSTransaction, sApprovalStaus);
            oNCSTransaction = (NCSTransaction)oResult.Return;

            if (oResult.Status)
            {
                Session.Add(Constants.SES_TRANSACTION_UPLOAD, oNCSTransaction);

                ddlFileTpe.SelectedItem.Text = oNCSTransaction.NCSFileType;
                txtUploadDate.Text = oNCSTransaction.NCSFileDate.ToString(Constants.DATETIME_FORMAT); ;
                txtTransactionDate.Text = oNCSTransaction.NCSTransDate.ToString(Constants.DATETIME_FORMAT); ;
                txtFileDetails.Text = oNCSTransaction.NCSFileDetails;
                txtNoofTXN.Text = oNCSTransaction.NCSNoofTrans.ToString("0");
                txtTotalTxnAmount.Text = oNCSTransaction.NCSTransAmount.ToString("N2");
                txtNCSTransNo.Text = oNCSTransaction.NCSTransNo;
                gvTransactionList.DataSource = oNCSTransaction.DtTransactions;
                gvTransactionList.DataBind();
                Session[Constants.SES_TRANSACTION_UPLOAD] = oNCSTransaction;
            }
            else
            {
                Session.Add(Constants.SES_TRANSACTION_UPLOAD, new NCSTransaction());
                ucMessage.OpenMessage(Constants.MSG_ERROR_NOT_FOUND, Constants.MSG_TYPE_ERROR);
            }
        }
        protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (!e.CommandName.Equals("Page"))
            {
                GridViewRow gvRow = (GridViewRow)((Button)e.CommandSource).NamingContainer;
                LoadDataByID(gvRow.Cells[1].Text, false);
            }
        }
        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            if (ddlFileTpe.SelectedValue == "PI")
            {
                Process_TransactionUpload("Profit");
            }
            else
            {
                Process_TransactionUpload("Encashment");
            }

        }


        private void Assign_Session()
        {
            NCSTransaction oTransactionUpload = (NCSTransaction)Session[Constants.SES_TRANSACTION_UPLOAD];
            oTransactionUpload.NCSFileType = ddlFileTpe.SelectedItem.Text;
            oTransactionUpload.NCSFileDate = Util.GetDateTimeByString(txtUploadDate.Text);
            oTransactionUpload.NCSTransDate = Util.GetDateTimeByString(txtTransactionDate.Text);
            oTransactionUpload.NCSFileDetails = txtFileDetails.Text;
            oTransactionUpload.NCSNoofTrans = Convert.ToInt32(txtNoofTXN.Text);
            oTransactionUpload.NCSTransAmount = Convert.ToDecimal(txtTotalTxnAmount.Text);
            oTransactionUpload.NCSTransNo = txtNCSTransNo.Text;
            if (oTransactionUpload.DtTransactions.Rows.Count <= 0)
            {
                if (gvTransactionList.DataSource != null)
                {
                    oTransactionUpload.DtTransactions = (DataTable)gvTransactionList.DataSource;
                }
            }
            Session[Constants.SES_TRANSACTION_UPLOAD] = oTransactionUpload;
        }
        private bool Process_TransactionUpload(string vPaymentType)
        {
            lFileStatus.Visible = true;
            bool result = false;
            string filePath = FileUpload1.PostedFile.FileName; // getting the file path of uploaded file  
            string filename = Path.GetFileName(filePath); // getting the file name of uploaded file  
            string ext = Path.GetExtension(filename); // getting the file extension of uploaded file  
            string type = System.String.Empty;
            if (!FileUpload1.HasFile)
            {
                lFileStatus.Text = "Please Select File"; //if file uploader has no file selected  
            }
            else
                if (FileUpload1.HasFile)
                {
                    try
                    {
                        switch (ext) // this switch code validate the files which allow to upload only excel file you can change it for any file  
                        {
                            case ".xls":
                                throw new Exception("Wrong file extention. Only *.xlsx file can be uploaded, Please check and upload again");
                            case ".xlsx":
                                type = "application/vnd.ms-excel";
                                break;
                        }
                        if (type != System.String.Empty)
                        {
                            txtFileDetails.Text = "";

                            StringBuilder sb = new StringBuilder();
                            try
                            {


                                sb.AppendFormat("Uploading file: {0}", FileUpload1.FileName);

                                //saving the file
                                filename = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName;
                                FileUpload1.SaveAs(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName);
                                //Showing the file information
                                sb.AppendFormat(" | File type: {0}", FileUpload1.PostedFile.ContentType);
                                sb.AppendFormat(" | File length: {0}", FileUpload1.PostedFile.ContentLength);

                                txtFileDetails.Text = sb.ToString();

                            }
                            catch (Exception ex)
                            {
                                sb.Append(" | Error <br/>");
                                sb.AppendFormat("Unable to upload file | {0}", ex.Message);
                                lFileStatus.Text = sb.ToString();
                            }
                            lFileStatus.Text = sb.ToString();

                            //return;

                            filePath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName;

                            //Stream fStream = FileUpload1.PostedFile.InputStream;
                            lFileStatus.ForeColor = System.Drawing.Color.Green;
                            lFileStatus.Text = "File Uploaded Successfully";

                            //Open the Excel file in Read Mode using OpenXml.
                            // Open the document for editing.

                            SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false);

                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            //Loop through the Worksheet rows.
                            string sSPTypeID = "";
                            string sPaymentType = vPaymentType;
                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {

                                    if (ddlFileTpe.SelectedItem.Value == "FI" || ddlFileTpe.SelectedItem.Value == "FE")
                                    {
                                        if (ddlFileTpe.SelectedItem.Value == "FI")
                                        {
                                            sPaymentType = "Interest";
                                        }
                                        else if (ddlFileTpe.SelectedItem.Value == "FI")
                                        {
                                            sPaymentType = "Principle";
                                        }
                                        dt.Columns.Add("SPTypeID");
                                        dt.Columns.Add("PaymentType");
                                        dt.Columns.Add("RegistrationNo");
                                        dt.Columns.Add("HolderName");
                                        dt.Columns.Add("NID");
                                        dt.Columns.Add("MaturityDate");
                                        dt.Columns.Add("IssueAmount");
                                        dt.Columns.Add("ClaimDate");
                                        dt.Columns.Add("PaymentAmount");
                                    }
                                    else
                                    {
                                        dt.Columns.Add("SPTypeID");
                                        dt.Columns.Add("PaymentType");
                                        dt.Columns.Add("RegistrationNo");
                                        dt.Columns.Add("IssueAmount");
                                        dt.Columns.Add("TransactionAmount");
                                        dt.Columns.Add("TaxAmount");
                                        dt.Columns.Add("AdjustAmount");
                                        dt.Columns.Add("PaymentAmount");
                                    }
                                }
                                else
                                {
                                    //Add rows to DataTable.
                                    if (sSPTypeID != "" && sPaymentType != "")
                                    {
                                        dt.Rows.Add();
                                    }
                                    int i = 0;
                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        string data = GetValue(doc, cell);
                                        data = data.Replace("\n", " ");
                                        switch (data)
                                        {
                                            case "সঞ্চয়পত্র / বন্ড এর ইএফটি বিবরণ ( আসল / মুনাফা প্রদান )":
                                                // code block
                                                break;
                                            case "ইএফটির তারিখ":
                                                // code block
                                                break;
                                            case "প্রতিষ্ঠানের নামঃ এইচএসবিসি, ঢাকা মেইন অফিস":
                                                // code block
                                                break;
                                            case "(অংকসমূহ টাকায়)":
                                                // code block
                                                break;
                                            case "স্কীম":
                                                // code block
                                                break;
                                            case "ট্র্যাকিং নং":
                                                // code block
                                                break;
                                            case "স্কীমের মূল্যমান":
                                                // code block
                                                break;
                                            case "প্রাপ্ত অর্থের পরিমাণ":
                                                // code block
                                                break;
                                            case "উৎসে আয়কর ":
                                                // code block
                                                break;
                                            case "সমন্বয়":
                                                // code block
                                                break;
                                            case "প্রাপ্ত অর্থ (নীট)":
                                                // code block
                                                break;

                                            case "৩-মাস অন্তর মুনাফা ভিত্তিক সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "3MS";
                                                dt.Rows.Add();
                                                break;
                                            case "৫-বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "BSP";
                                                dt.Rows.Add();
                                                break;
                                            case "পরিবার সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "FSP";
                                                dt.Rows.Add();
                                                break;
                                            case "ইএফটির ধরণঃআসল":
                                                sPaymentType = "Principle";
                                                break;
                                            case "ইএফটির ধরণঃমুনাফা":
                                                sPaymentType = "Interest";
                                                break;


                                            case "মোট  - ৩-মাস অন্তর মুনাফা ভিত্তিক সঞ্চয়পত্র  ":
                                                // code block
                                                sSPTypeID = "";
                                                dt.Rows.RemoveAt(dt.Rows.Count - 1);
                                                break;
                                            case "মোট  - পরিবার সঞ্চয়পত্র  ":
                                                // code block
                                                sSPTypeID = "";
                                                dt.Rows.RemoveAt(dt.Rows.Count - 1);
                                                break;
                                            case "মোট  - ৫-বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র  ":
                                                // code block
                                                sSPTypeID = "";
                                                dt.Rows.RemoveAt(dt.Rows.Count - 1);
                                                break;
                                            case "মোট-এইচএসবিসি, ঢাকা মেইন অফিস":
                                                // code block
                                                break;
                                            case "সর্বমোট:":
                                                // code block
                                                break;
                                            case "পৃষ্ঠাঃ  1/1":
                                                // code block
                                                break;

                                            case "Profit Payment Statement":
                                                // code block
                                                sPaymentType = "Interest";
                                                break;
                                            case "Principal Payment Statement":
                                                sPaymentType = "Principle";
                                                break;
                                            case "Bond: US Doller Investment Bond":
                                                sSPTypeID = "DIB";
                                                break;
                                            case "Bond: US Doller Premium Bond":
                                                sSPTypeID = "DPB";
                                                break;
                                            case "Bond: Wage Earner Development Bond":
                                                sSPTypeID = "WDB";
                                                break;
                                            case "Bank: HSBC":
                                                break;
                                            case "Branch: DHANMONDI":
                                                break;
                                            case "Trans. Staus: Approved (Issue Bank)":
                                                break;
                                            case "Bond Currency: USD":
                                                break;
                                            case "Bond Currency: BDT":
                                                break;
                                            case "Repayment Amount in USD":
                                                break;
                                            case "Repayment Amount in BDT":
                                                break;
                                            case "Reg. No.":
                                                break;
                                            case "Holder Name":
                                                break;
                                            case "Holder NID/Smart NID":
                                                break;
                                            case "Maturity Date":
                                                break;
                                            case "Bond Value":
                                                break;
                                            case "Claim Date":
                                                break;
                                            case "Profit Payment Amount":
                                                break;
                                            case "Total of Branch: DHANMONDI":
                                                break;
                                            case "Total of Bank: HSBC":
                                                break;
                                            case "Total of the Bond: US Doller Investment Bond":
                                                break;
                                            case "Total of the Bond: US Doller Premium Bond":
                                                break;
                                            case "Total of the Bond: Wage Earner Development Bond":
                                                break;
                                            case "Page -1 of 1":
                                                break;
                                            default:
                                                //code block
                                                if (data.Contains("Printed"))
                                                {
                                                    break;
                                                }
                                                if (sSPTypeID == "")
                                                {
                                                    break;
                                                }
                                                if (i == 0)
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][0] = sSPTypeID;
                                                    i++;
                                                    dt.Rows[dt.Rows.Count - 1][1] = sPaymentType;
                                                    i++;
                                                }
                                                dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                                i++;
                                                if (ddlFileTpe.SelectedItem.Value != "FI" && ddlFileTpe.SelectedItem.Value != "FE")
                                                {
                                                    if (GetValue(doc, cell).Trim().Length <= 3)
                                                    {
                                                        sPaymentType = "";
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                }
                            }
                            decimal paymentAmount = 0;
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (Convert.ToString(dt.Rows[i]["PaymentAmount"]) == "" || Convert.ToString(dt.Rows[i]["PaymentType"]).Length <= 3)
                                {

                                    dt.Rows.RemoveAt(i);
                                    i -= 1;
                                }
                                else
                                {
                                    paymentAmount += Convert.ToDecimal(dt.Rows[i]["PaymentAmount"]);
                                }
                            }

                            gvTransactionList.DataSource = dt;
                            gvTransactionList.DataBind();

                            txtNoofTXN.Text = dt.Rows.Count.ToString();
                            txtTotalTxnAmount.Text = paymentAmount.ToString("N2");
                            Assign_Session();

                            doc.Close();
                            
                            rows = null;
                            sheet = null;
                            worksheet = null;
                            doc = null;

                            if (System.IO.File.Exists(filename))
                            {
                                System.IO.File.Delete(filename);
                            }
                            
                        }
                        else
                        {
                            lFileStatus.ForeColor = System.Drawing.Color.Red;
                            lFileStatus.Text = "Select Only Excel File having extension .xlsx"; // if file is other than speified extension   
                        }
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        lFileStatus.ForeColor = System.Drawing.Color.Red;
                        lFileStatus.Text = "Error: " + ex.Message.ToString();
                    }
                }
            return result;
        }
        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue.InnerText;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
            }
            return value;
        }

        protected void gvTransactionList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTransactionList.PageIndex = e.NewPageIndex;
            if (Session[Constants.SES_TRANSACTION_UPLOAD] != null)
            {
                DataTable dtTmpList = ((NCSTransaction)Session[Constants.SES_TRANSACTION_UPLOAD]).DtTransactions;
                gvTransactionList.DataSource = dtTmpList;
                gvTransactionList.DataBind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                 Assign_Session();
                NCSTransaction oTransactionUpload = (NCSTransaction)Session[Constants.SES_TRANSACTION_UPLOAD];
                if (oTransactionUpload.DtTransactions.Rows.Count <= 0)
                {
                    ucMessage.OpenMessage("No transaction uploaded for save. Please check and upload!", Constants.MSG_TYPE_INFO);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }

                oTransactionUpload.UserDetails = ucUserDet.UserDetail;
                oTransactionUpload.UserDetails.MakerID = oConfig.UserName;
                oTransactionUpload.UserDetails.MakeDate = DateTime.Now;

                ucUserDet.ResetData();

                NSCUploadDAL oNCSUploadDAL = new NSCUploadDAL();
                Result oResult = (Result)oNCSUploadDAL.Save(oTransactionUpload);

                if (oResult.Status)
                {
                    InitializeData();
                    ucMessage.OpenMessage(Constants.MSG_SUCCESS_SAVE, Constants.MSG_TYPE_SUCCESS);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                    ucUserDet.ResetData();
                }
                else
                {
                    ucMessage.OpenMessage(Constants.MSG_ERROR_SAVE, Constants.MSG_TYPE_ERROR);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }
            }
            catch (Exception ex)
            {
                lFileStatus.ForeColor = System.Drawing.Color.Red;
                lFileStatus.Text = "Error: " + ex.Message.ToString();
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            NSCUploadDAL oNCSUploadDAL = new NSCUploadDAL();
            Result oResult = (Result)oNCSUploadDAL.Detete(txtNCSTransNo.Text);
            if (oResult.Status)
            {


                ddlFileTpe.SelectedIndex = 0;
                txtTransactionDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);
                txtUploadDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);

                txtFileDetails.Text = "";

                DataTable dt1 = new DataTable();
                gvTransactionList.DataSource = dt1;
                gvTransactionList.DataBind();

                LoadUnapproveList();

                if (Session[Constants.SES_TRANSACTION_UPLOAD] == null)
                {
                    NCSTransaction oSesTransactionUpload = new NCSTransaction();
                    Session.Add(Constants.SES_TRANSACTION_UPLOAD, oSesTransactionUpload);
                }
                else
                {
                    NCSTransaction oSesTransactionUpload = new NCSTransaction();
                    Session[Constants.SES_TRANSACTION_UPLOAD] = oSesTransactionUpload;
                }

                ucMessage.OpenMessage(Constants.MSG_SUCCESS_DELETE, Constants.MSG_TYPE_SUCCESS);
                ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
            }
            else
            {
                if (oResult.Message.Equals(Constants.TABLE_MAIN))
                {
                    ucMessage.OpenMessage(Constants.MSG_APPROVED_DELETE_DATA, Constants.MSG_TYPE_ERROR);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }
                else
                {
                    ucMessage.OpenMessage(Constants.MSG_ERROR_DELETE, Constants.MSG_TYPE_ERROR);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }
            }

        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            try
            {
                Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                Assign_Session();
                NCSTransaction oTransactionUpload = (NCSTransaction)Session[Constants.SES_TRANSACTION_UPLOAD];
                if (oTransactionUpload.DtTransactions.Rows.Count <= 0)
                {
                    ucMessage.OpenMessage("No transaction uploaded for approve. Please check and upload!", Constants.MSG_TYPE_INFO);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }

                oTransactionUpload.UserDetails = ucUserDet.UserDetail;
                oTransactionUpload.UserDetails.CheckerID = oConfig.UserName;
                oTransactionUpload.UserDetails.CheckDate = DateTime.Now;

                ucUserDet.ResetData();

                NSCUploadDAL oNCSUploadDAL = new NSCUploadDAL();
                Result oResult = (Result)oNCSUploadDAL.Approve(oTransactionUpload);

                if (oResult.Status)
                {
                    InitializeData();
                    ucMessage.OpenMessage(Constants.MSG_SUCCESS_APPROVE, Constants.MSG_TYPE_SUCCESS);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("Approve"), true);
                    ucUserDet.ResetData();
                }
                else
                {
                    ucMessage.OpenMessage(oResult.Message, Constants.MSG_TYPE_ERROR);
                    ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
                }
            }
            catch (Exception ex)
            {
                ucMessage.OpenMessage(ex.Message, Constants.MSG_TYPE_ERROR);
                ScriptManager.RegisterStartupScript(this.UpdatePanel2, typeof(string), Constants.POPUP_WINDOW, Util.OpenPopup("info"), true);
            }
        }
        public void PopErrorMsgAction(string sType)
        {
            ucMessage.ResetMessage("Operation in progress...");

            if (sType.Equals(Constants.BTN_APPROVE) || sType.Equals(Constants.BTN_REJECT))
            {
                Response.Redirect(Constants.PAGE_TRAN_APPROVAL + "?pType=" + Convert.ToString((int)Constants.PAGEINDEX_TRANS.TRANSACTION_UPLOAD).PadLeft(5, '0'), false);
            }
            else
            {
                btnUploadFile.Focus();
            }
        }
    }
}

